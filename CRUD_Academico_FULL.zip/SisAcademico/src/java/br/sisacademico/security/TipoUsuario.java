package br.sisacademico.security;

public enum TipoUsuario {
    admin,
    usuario
}
